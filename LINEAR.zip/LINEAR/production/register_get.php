<?php
$conn=mysqli_connect("localhost","root","","campaign");

$first=$_POST['first'];
$last=$_POST['last'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$do_you_want_whatsaap=$_POST['do_you_want_whatsaap'];
$whats_app_no=$_POST['whats_app_no'];
$firm_name=$_POST['firm_name'];
$gst_no=$_POST['gst_no'];
$address1=$_POST['address1'];
$address2=$_POST['address2'];
$city=$_POST['city'];
$state=$_POST['state'];
$zip=$_POST['zip'];
$industry=$_POST['industry'];
$customer_language=$_POST['customer_language'];
$age_group=$_POST['age_group'];
$gender=$_POST['gender'];
$no_of_employee=$_POST['no_of_employee'];
$intrested_customer=$_POST['intrested_customer'];

 $sql="insert into  register set first='".$first."',
last='".$last."',
email='".$email."',
phone='".$phone."',
do_you_want_whatsaap='".$do_you_want_whatsaap."',
whats_app_no='".$whats_app_no."',
firm_name='".$firm_name."',
gst_no='".$gst_no."',
address1='".$address1."',
address2='".$address2."',
city='".$city."',
state='".$state."',
zip='".$zip."',
industry='".$industry."',
customer_language='".implode(',',$customer_language)."',
age_group='".implode(',',$age_group)."',
gender='".$gender."',
no_of_employee='".$no_of_employee."',
intrested_customer='".implode(',',$intrested_customer)."'
";
$query=mysqli_query($conn,$sql) or die(mysqli_error($conn));
header("location:regestration1.html")
?>