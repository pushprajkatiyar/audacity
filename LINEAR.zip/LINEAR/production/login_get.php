<?php
$conn=mysqli_connect("localhost","root","","campaign");

$user=$_POST['user'];
$password=$_POST['password'];

$sql="insert into  log set user='".$user."',
password='".$password."'";

$query=mysqli_query($conn,$sql) or die(mysqli_error($conn));
header("location:loginproduct.html")
?>